'use strict'; // eslint-disable-line strict
require('babel/register');
require('./test.js');
