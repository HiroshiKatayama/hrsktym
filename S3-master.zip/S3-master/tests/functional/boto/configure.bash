#!/bin/bash
pip install pytest
