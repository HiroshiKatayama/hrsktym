'use strict'; // eslint-disable-line strict

require('babel-core/register');
require('./lib/server.js').default();
